## How to install

1. Install dependencies

```bash
npm install
```

2. Run project

```bash
npm run dev
```


